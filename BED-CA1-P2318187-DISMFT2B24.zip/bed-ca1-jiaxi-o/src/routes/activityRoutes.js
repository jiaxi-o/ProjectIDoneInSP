const express = require('express');
const activityController = require('../controllers/activityControllers');
const router = express.Router();

router.post('/:user_id/:pet_id/feed/:item_id', 
  activityController.getItemDetailsAndValidateType('snack'),
  activityController.checkInventory,
  activityController.updatePetStats('hunger'),
  activityController.removeItemFromInventory,
  activityController.logActivity('fed')
);

router.post('/:user_id/:pet_id/groom/:item_id', 
  activityController.getItemDetailsAndValidateType('grooming'),
  activityController.checkInventory,
  activityController.updatePetStats('happiness'),
  activityController.removeItemFromInventory,
  activityController.logActivity('groomed')
);

router.post('/:user_id/:pet_id/train/:item_id', 
  activityController.getItemDetailsAndValidateType('training'),
  activityController.checkInventory,
  activityController.updatePetStats('health'),
  activityController.removeItemFromInventory,
  activityController.logActivity('trained')
);

module.exports = router;
