const express = require('express');
const inventoryController = require('../controllers/inventoryControllers');
const router = express.Router();

//section B
router.get('/user/:user_id', inventoryController.getInventoryByUserId); // Get all inventory items

module.exports = router;
