// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187

const express = require('express');
const answerController = require('../controllers/answerControllers'); // Import answerControllers

const router = express.Router();

// Define Routes
router.post('/:question_id/answers', answerController.createAnswer); // Create a new answer
router.get('/:question_id/answers', answerController.readAllAnswers); // Read all answers

module.exports = router;