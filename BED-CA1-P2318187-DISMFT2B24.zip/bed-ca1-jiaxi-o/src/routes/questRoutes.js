const express = require('express');
const questController = require('../controllers/questControllers');
const router = express.Router();

router.post('/', questController.createQuest); // Create a new quest
router.get('/', questController.getQuests); // Get all quests
router.get('/:quest_id', questController.getQuestById); // Get a single quest
router.put('/:quest_id', questController.updateQuest); // Update a quest
router.delete('/:quest_id', questController.deleteQuest); // Delete a quest
router.post('/:quest_id/accept/user/:user_id', questController.acceptQuest); // Accept a quest
router.post('/:quest_id/complete/user/:user_id', questController.completeQuest); // Complete a quest

module.exports = router;
