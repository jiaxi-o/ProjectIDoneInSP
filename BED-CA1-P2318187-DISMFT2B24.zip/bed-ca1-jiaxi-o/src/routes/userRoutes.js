 // Import require modules
 const express = require('express');
 const userControllers = require('../controllers/userControllers'); // Import userController

 // Create Router
 const router = express.Router();

 // Define Routes
 //Section A
 //----------------------------------------------
 router.post('/', userControllers.createNewUser); // Create a new user(Endpoint:POST /users)
 router.get('/', userControllers.readAllUsers); // Read all users(Endpoint:GET /users)
 router.get('/:id', userControllers.readUserById); // Read user by id(Endpoint:GET /users/:user_id)
 router.put('/:id', userControllers.updateUserById); // Update user by id(Endpoint:PUT /users/:user_id)
 router.delete('/:id', userControllers.deleteUserById); // Delete user by id(Endpoint:DELETE /users/:user_id)
//----------------------------------------------
//Section B
//----------------------------------------------

 // Export Router to mainRoutes
 module.exports = router;