// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187/* ============================================================= */
/* ============================================================= */
/* Require Modules */
/* ============================================================= */
// Section A
const express = require('express');
const userRoutes = require('./userRoutes');
const questionRoutes = require('./questionRoutes');
const answerRoutes = require('./answerRoutes');
// Section B
const petRoutes = require('./petRoutes');
const questRoutes = require('./questRoutes');
const shopRoutes = require('./shopRoutes');
const activityRoutes = require('./activityRoutes');
const inventoryRoutes = require('./inventoryRoutes');
/* ============================================================= */
/* Create Router */
/* ============================================================= */
const router = express.Router();

/* ============================================================= */
/* Define Routes */
/* ============================================================= */
// Section A
router.use('/users', userRoutes); // Use userRoutes
router.use('/questions', questionRoutes); // Use questionRoutes
router.use('/questions', answerRoutes); // Use answerRoutes
// Section B
router.use('/pets', petRoutes); // Use petRoutes
router.use('/quests', questRoutes); // Use questRoutes
router.use('/shop', shopRoutes); // Use shopRoutes
router.use('/activities', activityRoutes); // Use activityRoutes
router.use('/inventory', inventoryRoutes); // Use inventoryRoutes
/* ============================================================= */
/* Export Router */
/* ============================================================= */
module.exports = router;