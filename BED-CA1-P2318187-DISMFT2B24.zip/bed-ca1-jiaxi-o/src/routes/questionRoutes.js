 // Import require modules
 const express = require('express');
 const questionControllers = require('../controllers/questionControllers'); // Import userController

 // Create Router
 const router = express.Router();

 // Define Routes
 //Section A
//----------------------------------------------
 router.post('/', questionControllers.createQuestion);  // Create a new question 
 router.get('/', questionControllers.readAllQuestions); // Read all questions
 router.get('/:id', questionControllers.readQuestionById); // Read question by id
 router.put('/:id', questionControllers.updateQuestionById); // Update question by id
 router.delete('/:id', questionControllers.deleteQuestionById); // Delete question by id
//----------------------------------------------
//Section B
//----------------------------------------------

 // Export Router to mainRoutes
 module.exports = router;