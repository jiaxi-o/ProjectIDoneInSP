const express = require('express');
const petController = require('../controllers/petControllers');
const router = express.Router();

router.post('/:user_id/createPet', petController.createPet); // Create a pet using an existing user ID
router.get('/allPets', petController.getPets); // Get all pets
router.get('/user/:user_id', petController.getPetsByUserId); // Get pets by user ID
router.get('/:pet_id', petController.getPetById); // Get a single pet by ID
router.put('/:user_id/pets/:pet_id', petController.updatePet); // Update a pet by ID
router.delete('/:user_id/pets/:pet_id', petController.deletePet); // Delete a pet by ID

module.exports = router;
