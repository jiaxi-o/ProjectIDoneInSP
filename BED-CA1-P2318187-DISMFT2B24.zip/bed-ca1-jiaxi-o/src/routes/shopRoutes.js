const express = require('express');
const shopController = require('../controllers/shopControllers');
const router = express.Router();

router.post('/items', shopController.createShopItem);
router.get('/items', shopController.getShopItems);
router.post('/user/:user_id/purchase/items/:item_id', shopController.purchaseItem); 

module.exports = router;
