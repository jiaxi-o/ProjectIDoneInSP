//////////////////////////////////////////////////////////////////////////////
// VARCHAR or TEXT
// 
// You can choose use either VARCHAR or TEXT for storing strings.
//////////////////////////////////////////////////////////////////////////////

const pool = require("../services/db");

const SQLSTATEMENT = `
 -- Drop tables if they exist
  DROP TABLE IF EXISTS UserAnswer;
  DROP TABLE IF EXISTS SurveyQuestion;
  DROP TABLE IF EXISTS Inventory;
  DROP TABLE IF EXISTS ActivityLog;
  DROP TABLE IF EXISTS Pet;
  DROP TABLE IF EXISTS UserQuest;
  DROP TABLE IF EXISTS Quest; 
  DROP TABLE IF EXISTS ShopItem;
  DROP TABLE IF EXISTS User;
  -- Create tables
  CREATE TABLE User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username TEXT,
    points INT DEFAULT 0
  );

  CREATE TABLE UserAnswer (
    answer_id INT AUTO_INCREMENT PRIMARY KEY,
    answered_question_id INT NOT NULL,
    participant_id INT NOT NULL,
    answer BOOL NOT NULL,
    creation_date DATE,
    additional_notes TEXT
  );

  CREATE TABLE SurveyQuestion (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    creator_id INT NOT NULL,
    question TEXT NOT NULL
  );

  CREATE TABLE Pet (
    pet_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    breed_name VARCHAR(255),
    breed_description TEXT,
    owner_id INT,
    fur_color VARCHAR(255),
    eye_color VARCHAR(255),
    hunger INT DEFAULT 0,
    happiness INT DEFAULT 100,
    health INT DEFAULT 100,
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
  );

  CREATE TABLE Quest (
    quest_id INT AUTO_INCREMENT PRIMARY KEY,
    quest_name VARCHAR(255),
    description TEXT,
    reward_points INT
  );

  CREATE TABLE ShopItem (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    price INT,
    item_type ENUM('snack', 'grooming', 'training'),
    effect_value INT
  );
  CREATE TABLE Inventory (
    inventory_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_id INT,
    quantity INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (item_id) REFERENCES ShopItem(item_id)
  );

  CREATE TABLE ActivityLog (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    pet_id INT,
    user_id INT,
    activity_type VARCHAR(255),
    activity_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pet_id) REFERENCES Pet(pet_id),
    FOREIGN KEY (user_id) REFERENCES User(user_id)
  );

  CREATE TABLE UserQuest (
    user_quest_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    quest_id INT,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (quest_id) REFERENCES Quest(quest_id)
  );
  -- Insert data into User table
  INSERT INTO User (username, points)
  VALUES
    ("socuser321", 0),    
    ("surveyKing", 0),
    ("greenUser123", 10);

  -- Insert data into Pet table
  INSERT INTO Pet (name, breed_name, breed_description, owner_id, fur_color, eye_color)
  VALUES
    ("Fluffy", "Pomeranian", "A small, fluffy dog breed.", 1, "white", "brown"),
    ("Buddy", "Golden Retriever", "A large, friendly dog breed.", 1, "golden", "brown"),
    ("Whiskers", "Siamese", "A small, short-haired cat breed.", 1, "white", "blue");

  -- Insert data into Quest table
  INSERT INTO Quest (quest_name, description, reward_points)
  VALUES
    ("Recycle e-waste", "Recycle e-waste at the designated area", 10),
    ("Turn off lights", "Turn off lights when not in use", 5),
    ("Visit cafe", "Visit the cafe at Moberly", 3);

  -- Insert data into ShopItem table
  INSERT INTO ShopItem (name, description, price, item_type, effect_value)
  VALUES
    ("Basic Snack", "Reduces hunger by 20.", 5, 'snack', 20),
    ("Premium Snack", "Reduces hunger by 50.", 10, 'snack', 50),
    ("Basic Grooming Kit", "Increases happiness by 20.", 5, 'grooming', 20),
    ("Deluxe Grooming Kit", "Increases happiness by 50.", 10, 'grooming', 50),
    ("Basic Training Equipment", "Increases health by 20.", 5, 'training', 20),
    ("Advanced Training Equipment", "Increases health by 50.", 10, 'training', 50);

  -- Insert data into SurveyQuestion table
  INSERT INTO SurveyQuestion (creator_id, question)
  VALUES
    (1, "Do you buy fruits from FC6?"),
    (1, "Is the fried chicken at FC5 salty?"),
    (2, "Did you recycled any e-waste?"),
    (2, "Do you turn off lights and appliances when not in use?"),
    (2, "Have you visit the cafe at Moberly?");
`;

pool.query(SQLSTATEMENT, (error, results, fields) => {
  if (error) {
    console.error("Error creating tables:", error);
  } else {
    console.log("Tables created successfully");
  }
  process.exit();
});

      