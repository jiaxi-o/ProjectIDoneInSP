const pool = require('../services/db');

module.exports.insertActivity = (data, callback) => {
  const SQLSTATEMENT = 'INSERT INTO ActivityLog (pet_id, user_id, activity_type) VALUES (?, ?, ?)';
  const VALUES = [data.pet_id, data.user_id, data.activity_type];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.updatePetStats = (data, callback) => {
  const SQLSTATEMENT = `
    UPDATE Pet
    SET hunger = IFNULL(hunger + ?, hunger),
        happiness = IFNULL(happiness + ?, happiness),
        health = IFNULL(health + ?, health)
    WHERE pet_id = ?
  `;
  const VALUES = [data.hunger || 0, data.happiness || 0, data.health || 0, data.pet_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

