// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187

const pool = require('../services/db'); // Import database connection

// Insert new user
module.exports.insertUser = (data, callback) => {
    const sql = "INSERT INTO User (username, points) VALUES (?, 0)";
    pool.query(sql, [data.username], callback);
};

module.exports.selectUserByUsername = (data, callback) => {
    const SQLSTATEMENT = 'SELECT * FROM User WHERE username = ?';
    pool.query(SQLSTATEMENT, [data.username], callback);
};

// Select all users
module.exports.selectAll = (callback) => {
    const sql = "SELECT * FROM User";
    pool.query(sql, callback);
};

// Select user by ID
module.exports.selectById = (data, callback) => {
    const sql = "SELECT * FROM User WHERE user_id = ?";
    pool.query(sql, [data.user_id], callback);
};

// Select completed questions count by user ID
module.exports.selectCompletedQuestionsByUserId = (user_id, callback) => {
    const sql = "SELECT COUNT(*) as completed_questions FROM UserAnswer WHERE participant_id = ? AND answer IS NOT NULL";
    pool.query(sql, [user_id], callback);
};

// Update user by ID
module.exports.updateById = (data, callback) => {
    const sql = "UPDATE User SET username = ? WHERE user_id = ?";
    pool.query(sql, [data.username, data.id], callback);
};

// Delete user by ID
module.exports.deleteById = (data, callback) => {
    const sql = "DELETE FROM User WHERE user_id = ?";
    pool.query(sql, [data.id], callback);
};