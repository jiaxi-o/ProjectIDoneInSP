const pool = require('../services/db');

module.exports.insertSingle = (data, callback) => {
  const SQLSTATEMENT = 'INSERT INTO Quest (quest_name, description, reward_points) VALUES (?, ?, ?)';
  const VALUES = [data.quest_name, data.description, data.reward_points];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAll = (callback) => {
  const SQLSTATEMENT = 'SELECT * FROM Quest';
  pool.query(SQLSTATEMENT, callback);
};

module.exports.selectById = (data, callback) => {
  const SQLSTATEMENT = 'SELECT * FROM Quest WHERE quest_id = ?';
  const VALUES = [data.quest_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.updateById = (data, callback) => {
  const SQLSTATEMENT = 'UPDATE Quest SET quest_name = ?, description = ?, reward_points = ? WHERE quest_id = ?';
  const VALUES = [data.quest_name, data.description, data.reward_points, data.quest_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.deleteById = (data, callback) => {
  const SQLSTATEMENT = 'DELETE FROM Quest WHERE quest_id = ?';
  const VALUES = [data.quest_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.completeQuest = (data, callback) => {
  const SQLSTATEMENT = 'UPDATE User SET points = points + (SELECT reward_points FROM Quest WHERE quest_id = ?) WHERE user_id = ?';
  const VALUES = [data.quest_id, data.user_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.acceptQuest = (data, callback) => {
  const SQLSTATEMENT = 'INSERT INTO UserQuest (user_id, quest_id) VALUES (?, ?)';
  const VALUES = [data.user_id, data.quest_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};