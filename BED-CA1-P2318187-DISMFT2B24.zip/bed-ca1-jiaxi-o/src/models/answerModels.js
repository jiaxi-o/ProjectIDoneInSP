// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187

const pool = require('../services/db'); // Import database connection

// Insert a new answer
module.exports.insertAnswer = (data, callback) => {
    const sql = "INSERT INTO UserAnswer (answered_question_id, participant_id, answer, creation_date, additional_notes) VALUES (?, ?, ?, ?, ?)";
    pool.query(sql, [data.answered_question_id, data.participant_id, data.answer, data.creation_date, data.additional_notes], callback);
};

// Select all answers for a specific question
module.exports.selectAllByQuestionId = (question_id, callback) => {
    const sql = "SELECT * FROM UserAnswer WHERE answered_question_id = ?";
    pool.query(sql, [question_id], callback);
};

// Update user points
module.exports.updateUserPoints = (user_id, callback) => {
    const sql = "UPDATE User SET points = points + 5 WHERE user_id = ?";
    pool.query(sql, [user_id], callback);
};

// Check if the question and user exist
module.exports.checkExistence = (data, callback) => {
    const sql = "SELECT * FROM SurveyQuestion WHERE question_id = ?; SELECT * FROM User WHERE user_id = ?";
    pool.query(sql, [data.question_id, data.user_id], callback);
};