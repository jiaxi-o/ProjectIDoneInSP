const pool = require('../services/db');
// Section B: 
//------------------------------------------
// getting all items in the inventory by user_id
//------------------------------------------
module.exports.selectByUserId = (data, callback) => {
  const SQLSTATEMENT = 'SELECT * FROM Inventory WHERE user_id = ?';
  const VALUES = [data.user_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

//------------------------------------------
// checking if the item is in the inventory
//------------------------------------------
module.exports.checkItemInInventory = (data, callback) => {
  const SQLSTATEMENT = 'SELECT quantity FROM Inventory WHERE user_id = ? AND item_id = ?';
  const VALUES = [data.user_id, data.item_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};
//------------------------------------------
// remove item from inventory
//------------------------------------------
module.exports.removeItemFromInventory = (data, callback) => {
  const SQLSTATEMENT = 'UPDATE Inventory SET quantity = quantity - 1 WHERE user_id = ? AND item_id = ?';
  const VALUES = [data.user_id, data.item_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

//------------------------------------------
// add item to inventory
//------------------------------------------
module.exports.addItemToInventory = (data, callback) => {
  const SQLSTATEMENT = `
    INSERT INTO Inventory (user_id, item_id, quantity) 
    VALUES (?, ?, ?) 
    ON DUPLICATE KEY UPDATE quantity = quantity + 1
  `;
  const VALUES = [data.user_id, data.item_id, data.quantity || 1];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

//------------------------------------------
// getting all items in the inventory
//------------------------------------------
module.exports.insertItem = (data, callback) => {
  const SQLSTATEMENT = 'INSERT INTO Inventory (user_id, item_id, quantity) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1';
  const VALUES = [data.user_id, data.item_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};