const pool = require('../services/db');

module.exports.insertSingle = (data, callback) => {
  const SQLSTATEMENT = 'INSERT INTO ShopItem (name, description, price, item_type, effect_value) VALUES (?, ?, ?, ?, ?)';
  const VALUES = [data.name, data.description, data.price, data.item_type, data.effect_value];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectAll = (callback) => {
  const SQLSTATEMENT = 'SELECT * FROM ShopItem';
  pool.query(SQLSTATEMENT, callback);
};

module.exports.getItemById = (data, callback) => {
  const SQLSTATEMENT = 'SELECT * FROM ShopItem WHERE item_id = ?';
  const VALUES = [data.item_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.checkPoints = (data, callback) => {
  const SQLSTATEMENT = 'SELECT User.points, ShopItem.price FROM User, ShopItem WHERE User.user_id = ? AND ShopItem.item_id = ?';
  const VALUES = [data.user_id, data.item_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.updatePoints = (data, callback) => {
  const SQLSTATEMENT = 'UPDATE User SET points = points - (SELECT price FROM ShopItem WHERE item_id = ?) WHERE user_id = ?';
  const VALUES = [data.item_id, data.user_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};
