const pool = require('../services/db'); // Import database connection

// Insert new question
module.exports.insertQuestion = (data, callback) => {
    const sql = "INSERT INTO SurveyQuestion (creator_id, question) VALUES (?, ?)";
    pool.query(sql, [data.creator_id, data.question], callback);
};

// Select all questions
module.exports.selectAll = (callback) => {
    const sql = "SELECT * FROM SurveyQuestion";
    pool.query(sql, callback);
};

// Select question by ID
module.exports.selectById = (data, callback) => {
    const sql = "SELECT * FROM SurveyQuestion WHERE question_id = ?";
    pool.query(sql, [data.question_id], callback);
};

// Update question by ID
module.exports.updateById = (data, callback) => {
    const sql = "UPDATE SurveyQuestion SET question = ? WHERE question_id = ?";
    pool.query(sql, [data.question, data.question_id], callback);
};

// Delete question by ID
module.exports.deleteById = (data, callback) => {
    const sql = "DELETE FROM SurveyQuestion WHERE question_id = ?";
    pool.query(sql, [data.question_id], callback);
};