const pool = require('../services/db');

module.exports.insertSingle = (data, callback) => {
    const SQLSTATEMENT = 'INSERT INTO Pet (name, breed_name, breed_description, owner_id, fur_color, eye_color, hunger, happiness, health) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
    const VALUES = [data.name, data.breed_name, data.breed_description, data.owner_id, data.fur_color, data.eye_color, data.hunger || 100, data.happiness || 100, data.health || 100];
    pool.query(SQLSTATEMENT, VALUES, callback);
  };

module.exports.selectAll = (callback) => {
  const SQLSTATEMENT = 'SELECT * FROM Pet';
  pool.query(SQLSTATEMENT, callback);
};

module.exports.selectById = (data, callback) => {
  const SQLSTATEMENT = 'SELECT * FROM Pet WHERE pet_id = ?';
  const VALUES = [data.pet_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectByUserId = (data, callback) => {
    const SQLSTATEMENT = 'SELECT * FROM Pet WHERE owner_id = ?';
    const VALUES = [data.user_id];
    pool.query(SQLSTATEMENT, VALUES, callback);
  };

  module.exports.updateById = (data, callback) => {
    const SQLSTATEMENT = 'UPDATE Pet SET name = ?, breed_name = ?, breed_description = ?, owner_id = ?, fur_color = ?, eye_color = ?, hunger = ?, happiness = ?, health = ? WHERE pet_id = ?';
    const VALUES = [data.name, data.breed_name, data.breed_description, data.owner_id, data.fur_color, data.eye_color, data.hunger, data.happiness, data.health, data.pet_id];
    pool.query(SQLSTATEMENT, VALUES, callback);
  };

module.exports.deleteById = (data, callback) => {
  const SQLSTATEMENT = 'DELETE FROM Pet WHERE pet_id = ?';
  const VALUES = [data.pet_id];
  pool.query(SQLSTATEMENT, VALUES, callback);
};
