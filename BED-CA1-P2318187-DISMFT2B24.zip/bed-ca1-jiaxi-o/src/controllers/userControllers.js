// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187
const model = require('../models/userModels.js'); // Import the model (Database user table)

module.exports.createNewUser = (req, res) => {
    if (req.body.username === undefined) {
        res.status(400).send("Error: Username is undefined");
        return;
    }

    const data = {
        username: req.body.username
    };

    const checkCallback = (error, results, fields) => {
        if (error) {
            console.log("Error checking username:", error);
            res.status(500).json(error);
        } else if (results.length != 0) {
            res.status(409).send("Error: Username already exists"); // 409 Conflict
        } else {
            const insertCallback = (insertError, insertResults, insertFields) => {
                if (insertError) {
                    console.log("Error creating user:", insertError);
                    res.status(500).json(insertError);
                } else {
                    const id = insertResults.insertId; // Get the ID of the newly created user
                    res.status(201).json({
                        user_id: id,
                        username: req.body.username,
                        points: 0
                    });
                }
            };
            model.insertUser(data, insertCallback);
        }
    };

    model.selectUserByUsername(data, checkCallback);
};


/* ============================================================= */
/* Define controller to get all users */
/* ============================================================= */
module.exports.readAllUsers = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            console.log("Error getAllUser:", error);
            res.status(500).json(error);
        }
        else {
            res.status(200).json(results);
        }
    }
    model.selectAll(callback);
}
/* ============================================================= */
/* Define controller to get user by ID */
/* ============================================================= */
module.exports.readUserById = (req, res, next) => {
    const data = { user_id: req.params.id };

    //console.log("Data:", data);  // Log the data to ensure the correct user ID is being passed

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error selecting user by ID:", error);
            res.status(500).json(error);
        } else {
            //console.log("Results:", results);  // Log the results to see what is returned
            if (results.length === 0) {
                res.status(404).json({ message: "User not found." });
            } else {
                const user = results[0];
                model.selectCompletedQuestionsByUserId(data.user_id, (error, completedResults) => {
                    if (error) {
                        console.error("Error selecting completed questions:", error);  // Log the error
                        res.status(500).json(error);
                    } else {
                        console.log("Completed Questions:", completedResults);  // Log the completed questions results
                        user.completed_questions = completedResults.length > 0 ? completedResults[0].completed_questions : [];
                        res.status(200).json(user);
                    }
                });
            }
        }
    };

    model.selectById(data, callback);
};



/* ============================================================= */
/* Define controller to update user by ID */
/* ============================================================= */
/* ============================================================= */
/* Define controller to update user by ID */
/* ============================================================= */
module.exports.updateUserById = (req, res, next) => {
    if (req.body.username === undefined) {
        res.status(400).json({ message: "Missing required data." });
        return;
    }

    const data = { id: req.params.id, username: req.body.username };

    // First, check if the user_id exists
    const checkUserIdCallback = (error, results, fields) => {
        if (error) {
            console.log("Error checking user ID:", error);
            res.status(500).json(error);
        } else if (results.length === 0) {
            res.status(404).json({ message: "User not found" });
        } else {
            // Next, check if the provided username already exists for another user
            const checkUsernameCallback = (error, usernameResults, fields) => {
                if (error) {
                    console.log("Error checking username:", error);
                    res.status(500).json(error);
                } else if (usernameResults.length != 0 && usernameResults[0].user_id != data.id) {
                    res.status(409).json({ message: "Error: Username already exists" }); // 409 Conflict
                } else {
                    // If username does not exist for another user or it is the same user, update the user
                    const updateCallback = (updateError, updateResults, updateFields) => {
                        if (updateError) {
                            console.log("Error updating user:", updateError);
                            res.status(500).json(updateError);
                        } else {
                            // Fetch the updated user details
                            model.selectById({ user_id: data.id }, (selectError, selectResults) => {
                                if (selectError) {
                                    res.status(500).json(selectError);
                                } else {
                                    const updatedUser = selectResults[0];
                                    res.status(200).json({
                                        user_id: updatedUser.user_id,
                                        username: updatedUser.username,
                                        points: updatedUser.points
                                    });
                                }
                            });
                        }
                    };

                    model.updateById(data, updateCallback);
                }
            };

            model.selectUserByUsername(data, checkUsernameCallback);
        }
    };

    model.selectById({ user_id: data.id }, checkUserIdCallback);
};

// Delete user by ID
module.exports.deleteUserById = (req, res, next) => {
    const data = { id: req.params.id };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if(results.affectedRows === 0) {
                res.status(404).json({ message: "User not found." });
            } else {
                res.status(204).send();
            }
        }
    };

    model.deleteById(data, callback);
};