const shopModel = require('../models/shopModels');
const inventoryModel = require('../models/inventoryModels'); // Import the inventory model
// Section B:

// Create a new shop item
module.exports.createShopItem = (req, res) => {
  const { name, description, price, item_type, effect_value } = req.body;
  if (!name || !description || !price || !item_type || !effect_value) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const data = { name, description, price, item_type, effect_value };

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error createShopItem:', error);
      res.status(500).json(error);
    } else {
      res.status(201).json({ item_id: results.insertId, ...data });
    }
  };

  shopModel.insertSingle(data, callback);
};

// Get all shop items
module.exports.getShopItems = (req, res) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getShopItems:', error);
      res.status(500).json(error);
    } else {
      res.status(200).json(results);
    }
  };

  shopModel.selectAll(callback);
};

// purchase an item
module.exports.purchaseItem = (req, res) => {
  const { user_id, item_id } = req.params;
  if (!user_id || !item_id) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const data = { user_id, item_id };

  const checkPointsCallback = (error, results, fields) => {
    if (error) {
      console.error('Error checkPoints:', error);
      return res.status(500).json(error);
    }

    if (results.length === 0 || results[0].points < results[0].price) {
      return res.status(400).json({ error: 'Not enough points or invalid user/item' });
    }

    const updatePointsCallback = (updateError, updateResults, updateFields) => {
      if (updateError) {
        console.error('Error updatePoints:', updateError);
        return res.status(500).json(updateError);
      }

      inventoryModel.insertItem(data, (inventoryError, inventoryResults, inventoryFields) => {
        if (inventoryError) {
          console.error('Error addItemToInventory:', inventoryError);
          return res.status(500).json(inventoryError);
        }

        res.status(201).json({ inventory_id: inventoryResults.insertId, ...data });
      });
    };

    shopModel.updatePoints(data, updatePointsCallback);
  };

  shopModel.checkPoints(data, checkPointsCallback);
};
