// =====================================================================================================================================================================================
// Name: Ong Jia Xi
// Class: DISM/FT/2B/24
// Admission Number: P2318187

const model = require('../models/answerModels'); // Import the model (Database answer table)

/* ============================================================= */
/* Define controller to create an answer */
/* ============================================================= */
module.exports.createAnswer = (req, res, next) => {
    const question_id = req.params.question_id;
    const { user_id, answer, creation_date, additional_notes } = req.body;

    if (user_id === undefined || answer === undefined || creation_date === undefined) {
        res.status(400).json({ message: "Bad Request: Missing required fields in the request body." });
        return;
    }

    const data = { answered_question_id: question_id, participant_id: user_id, answer, creation_date, additional_notes };

    // First, check if the question_id and user_id exist
    const checkExistenceCallback = (error, results, fields) => {
        if (error) {
            console.log("Error checking existence:", error);
            res.status(500).json({ message: "Internal Server Error." });
        } else if (results[0].length === 0 || results[1].length === 0) {
            res.status(404).json({ message: "Question or user not found." });
        } else {
            // Insert the answer into UserAnswer table
            const insertCallback = (insertError, insertResults, insertFields) => {
                if (insertError) {
                    console.log("Error inserting answer:", insertError);
                    res.status(500).json({ message: "Internal Server Error." });
                } else {
                    const id = insertResults.insertId;
                    res.status(201).json({
                        "answer_id": id,
                        "answered_question_id": question_id,
                        "participant_id": user_id,
                        "answer": answer,
                        "creation_date": creation_date,
                        "additional_notes": additional_notes
                    });

                    // Update user points after successfully creating an answer
                    model.updateUserPoints(user_id, (updateError, updateResults) => {
                        if (updateError) {
                            console.error("Error updating user points:", updateError);
                        }
                    });
                }
            };

            model.insertAnswer(data, insertCallback);
        }
    };

    model.checkExistence({ question_id, user_id }, checkExistenceCallback);
};


// Get all answers for a specific question
module.exports.readAllAnswers = (req, res, next) => {
    const question_id = req.params.question_id;

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if(results.length === 0) {
                res.status(404).json({ message: "No answers found for the specified question." });
            } else {
                res.status(200).json(results);
            }
        }
    };

    model.selectAllByQuestionId(question_id, callback);
};