const petModel = require('../models/petModels');
const userModel = require('../models/userModels');
// create a pet using an existing user ID
module.exports.createPet = (req, res) => {
    const { user_id } = req.params;
    const { name, breed_name, breed_description, fur_color, eye_color } = req.body;
    if (!name || !breed_name || !breed_description || !fur_color || !eye_color || !user_id) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
  
    const data = { name, breed_name, breed_description, owner_id: user_id, fur_color, eye_color };
  
    const callback = (error, results, fields) => {
      if (error) {
        console.error('Error createPet:', error);
        res.status(500).json(error);
      } else {
        res.status(201).json({ pet_id: results.insertId, ...data });
      }
    };
  
    petModel.insertSingle(data, callback);
  };;

module.exports.getPets = (req, res) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getPets:', error);
      res.status(500).json(error);
    } else {
      res.status(200).json(results);
    }
  };

  petModel.selectAll(callback);
};

// Get all pets by user ID
module.exports.getPetsByUserId = (req, res) => {
  const { user_id } = req.params;

  // First, check if the user exists
  const checkUserCallback = (error, userResults, fields) => {
    if (error) {
      console.error('Error checking user:', error);
      res.status(500).json(error);
    } else if (userResults.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      // If user exists, check for their pets
      const checkPetsCallback = (error, petResults, fields) => {
        if (error) {
          console.error('Error getPetsByUserId:', error);
          res.status(500).json(error);
        } else if (petResults.length === 0) {
          res.status(404).json({ error: 'No pets found for this user. Please create a pet.' });
        } else {
          res.status(200).json(petResults);
        }
      };

      petModel.selectByUserId({ user_id }, checkPetsCallback);
    }
  };

  userModel.selectById({ user_id }, checkUserCallback);
};


module.exports.getPetById = (req, res) => {
  const { pet_id } = req.params;

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getPetById:', error);
      res.status(500).json(error);
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: 'Pet not found' });
      } else {
        res.status(200).json(results[0]);
      }
    }
  };

  petModel.selectById({ pet_id }, callback);
};


// Update a pet by ID
module.exports.updatePet = (req, res) => {
  const { user_id, pet_id } = req.params;
  const { name, breed_name, breed_description, owner_id, fur_color, eye_color, hunger, happiness, health } = req.body;

  if (!name || !breed_name || !breed_description || !owner_id || !fur_color || !eye_color || hunger === undefined || happiness === undefined || health === undefined) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const data = { pet_id, name, breed_name, breed_description, owner_id, fur_color, eye_color, hunger, happiness, health };

  const checkOwnershipCallback = (error, results, fields) => {
    if (error) {
      console.error('Error retrieving pet:', error);
      res.status(500).json(error);
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: 'Pet not found' });
      } else {
        const pet = results[0];
        if (pet.owner_id !== parseInt(user_id)) {
          res.status(403).json({ error: 'Forbidden: You do not have permission to update this pet' });
        } else {
          const updateCallback = (error, results, fields) => {
            if (error) {
              console.error('Error updating pet:', error);
              res.status(500).json(error);
            } else {
              if (results.affectedRows === 0) {
                res.status(404).json({ error: 'Pet not found' });
              } else {
                res.status(200).json({ pet_id, ...data });
              }
            }
          };

          petModel.updateById(data, updateCallback);
        }
      }
    }
  };

  petModel.selectById({ pet_id }, checkOwnershipCallback);
};


// Delete a pet by ID
module.exports.deletePet = (req, res) => {
  const { user_id, pet_id } = req.params;

  const checkOwnershipCallback = (error, results, fields) => {
    if (error) {
      console.error('Error retrieving pet:', error);
      res.status(500).json(error);
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: 'Pet not found' });
      } else {
        const pet = results[0];
        if (pet.owner_id !== parseInt(user_id)) {
          res.status(403).json({ error: 'Forbidden: You do not have permission to delete this pet' });
        } else {
          const deleteCallback = (error, results, fields) => {
            if (error) {
              console.error('Error deleting pet:', error);
              res.status(500).json(error);
            } else {
              if (results.affectedRows === 0) {
                res.status(404).json({ error: 'Pet not found' });
              } else {
                res.status(204).send();
              }
            }
          };

          petModel.deleteById({ pet_id }, deleteCallback);
        }
      }
    }
  };

  petModel.selectById({ pet_id }, checkOwnershipCallback);
};
