const inventoryModel = require('../models/inventoryModels');

//section B
// Get all inventory items by user_id
module.exports.getInventoryByUserId = (req, res) => {
  const { user_id } = req.params;

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getInventoryByUserId:', error);
      res.status(500).json(error);
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: 'No inventory items found for this user' });
      } else {
        res.status(200).json(results);
      }
    }
  };

  inventoryModel.selectByUserId({ user_id }, callback);
};  
