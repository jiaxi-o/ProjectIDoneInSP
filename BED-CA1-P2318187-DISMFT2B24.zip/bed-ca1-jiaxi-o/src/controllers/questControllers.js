const questModel = require('../models/questModels');

module.exports.createQuest = (req, res) => {
  const { quest_name, description, reward_points } = req.body;
  if (!quest_name || !description || !reward_points) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const data = { quest_name, description, reward_points };

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error createQuest:', error);
      res.status(500).json(error);
    } else {
      res.status(201).json({ quest_id: results.insertId, ...data });
    }
  };

  questModel.insertSingle(data, callback);
};

module.exports.getQuests = (req, res) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getQuests:', error);
      res.status(500).json(error);
    } else {
      res.status(200).json(results);
    }
  };

  questModel.selectAll(callback);
};

module.exports.getQuestById = (req, res) => {
  const { quest_id } = req.params;

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error getQuestById:', error);
      res.status(500).json(error);
    } else {
      if (results.length === 0) {
        res.status(404).json({ error: 'Quest not found' });
      } else {
        res.status(200).json(results[0]);
      }
    }
  };

  questModel.selectById({ quest_id }, callback);
};

module.exports.updateQuest = (req, res) => {
  const { quest_id } = req.params;
  const { quest_name, description, reward_points } = req.body;
  if (!quest_name || !description || !reward_points) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const data = { quest_id, quest_name, description, reward_points };

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error updateQuest:', error);
      res.status(500).json(error);
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Quest not found' });
      } else {
        res.status(200).json({ quest_id, ...data });
      }
    }
  };

  questModel.updateById(data, callback);
};

module.exports.deleteQuest = (req, res) => {
  const { quest_id } = req.params;

  const callback = (error, results, fields) => {
    if (error) {
      console.error('Error deleteQuest:', error);
      res.status(500).json(error);
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ error: 'Quest not found' });
      } else {
        res.status(204).send();
      }
    }
  };

  questModel.deleteById({ quest_id }, callback);
};

const userModel = require('../models/userModels');
const petModel = require('../models/petModels');

module.exports.acceptQuest = (req, res) => {
  const { quest_id, user_id } = req.params;

  if (!quest_id || !user_id) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Check if the user exists and has pets
  userModel.selectById({ user_id }, (userError, userResults) => {
    if (userError) {
      res.status(500).json({ error: 'Internal server error while checking user' });
    } else if (userResults.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      petModel.selectByUserId({ user_id }, (petError, petResults) => {
        if (petError) {
          res.status(500).json({ error: 'Internal server error while checking pets' });
        } else if (petResults.length === 0) {
          res.status(404).json({ error: 'User cannot accept quest since user does not have any pets' });
        } else {
          // Proceed to accept the quest
          questModel.selectById({ quest_id }, (questError, questResults) => {
            if (questError) {
              res.status(500).json({ error: 'Internal server error while checking quest' });
            } else if (questResults.length === 0) {
              res.status(404).json({ error: 'Quest not found' });
            } else {
              questModel.acceptQuest({ quest_id, user_id }, (acceptError, acceptResults) => {
                if (acceptError) {
                  res.status(500).json({ error: 'Internal server error while accepting quest' });
                } else {
                  res.status(200).json({ message: 'Quest accepted successfully' });
                }
              });
            }
          });
        }
      });
    }
  });
};

module.exports.completeQuest = (req, res) => {
  const { quest_id, user_id } = req.params;

  if (!quest_id || !user_id) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Check if the user exists
  userModel.selectById({ user_id }, (userError, userResults) => {
    if (userError) {
      res.status(500).json({ error: 'Internal server error while checking user' });
    } else if (userResults.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      // Check if the user has a pet
      petModel.selectByUserId({ user_id }, (petError, petResults) => {
        if (petError) {
          res.status(500).json({ error: 'Internal server error while checking pets' });
        } else if (petResults.length === 0) {
          res.status(404).json({ error: 'User does not have any pets' });
        } else {
          // Check if the quest exists
          questModel.selectById({ quest_id }, (questError, questResults) => {
            if (questError) {
              res.status(500).json({ error: 'Internal server error while checking quest' });
            } else if (questResults.length === 0) {
              res.status(404).json({ error: 'Quest not found' });
            } else {
              // Mark the quest as completed
              questModel.completeQuest({ quest_id, user_id }, (completeError, completeResults) => {
                if (completeError) {
                  res.status(500).json({ error: 'Internal server error while completing quest' });
                } else if (completeResults.affectedRows === 0) {
                  res.status(404).json({ error: 'Quest not found or user has not completed the quest' });
                } else {
                  res.status(200).json({ message: 'Quest completed and points awarded' });
                }
              });
            }
          });
        }
      });
    }
  });
};