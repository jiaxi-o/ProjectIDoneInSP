const model = require('../models/questionModels'); // Import the model (Database question table)

// Create a new question
module.exports.createQuestion = (req, res, next) => {
    if(req.body.user_id === undefined || req.body.question === undefined) {
        res.status(400).json({ message: "Bad Request: Missing user_id or question in the request body." });
        return;
    }

    const data = { creator_id: req.body.user_id, question: req.body.question };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json({ message: "Internal Server Error." });
        } else {
            const id = results.insertId;
            res.status(201).json({
                "question_id": id,
                "question": data.question,
                "creator_id": data.creator_id
            });
        }
    };

    model.insertQuestion(data, callback);
};

// Get all questions
module.exports.readAllQuestions = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            res.status(200).json(results);
        }
    };

    model.selectAll(callback);
};

// Get question by ID
module.exports.readQuestionById = (req, res, next) => {
    const data = { question_id: req.params.id };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if(results.length === 0) {
                res.status(404).json({ message: "Question not found." });
            } else {
                res.status(200).json(results[0]);
            }
        }
    };

    model.selectById(data, callback);
};

/* ============================================================= */
/* Define controller to update question by ID */
/* ============================================================= */
module.exports.updateQuestionById = (req, res, next) => {
    if (req.body.user_id === undefined || req.body.question === undefined) {
        res.status(400).json({ message: "Missing required data." });
        return;
    }

    const data = { question_id: req.params.id, creator_id: req.body.user_id, question: req.body.question };

    console.log("Received data:", data);

    // First, check if the question_id exists and fetch its details
    const checkQuestionCallback = (error, results, fields) => {
        if (error) {
            console.log("Error checking question ID:", error);
            res.status(500).json(error);
        } else if (results.length === 0) {
            console.log("Question not found for question_id:", data.question_id);
            res.status(404).json({ message: "Question not found" });
        } else {
            const question = results[0];
            console.log("Question found:", question);
            // Check if the creator_id matches
            if (question.creator_id != data.creator_id) {
                console.log("Forbidden: creator_id does not match for question_id:", data.question_id);
                res.status(403).json({ message: "Forbidden: You are not the owner of this question" });
            } else {
                // Update the question if creator_id matches
                const updateCallback = (updateError, updateResults, updateFields) => {
                    if (updateError) {
                        console.log("Error updating question:", updateError);
                        res.status(500).json(updateError);
                    } else {
                        console.log("Question updated successfully, fetching updated question details.");
                        // Fetch the updated question details
                        model.selectById({ question_id: data.question_id }, (selectError, selectResults) => {
                            if (selectError) {
                                res.status(500).json(selectError);
                            } else {
                                const updatedQuestion = selectResults[0];
                                res.status(200).json({
                                    question_id: updatedQuestion.question_id,
                                    question: updatedQuestion.question,
                                    creator_id: updatedQuestion.creator_id
                                });
                            }
                        });
                    }
                };

                model.updateById(data, updateCallback);
            }
        }
    };

    model.selectById({ question_id: data.question_id }, checkQuestionCallback);
};

// Delete question by ID
module.exports.deleteQuestionById = (req, res, next) => {
    const data = { question_id: req.params.id };

    const callback = (error, results, fields) => {
        if (error) {
            res.status(500).json(error);
        } else {
            if(results.affectedRows === 0) {
                res.status(404).json({ message: "Question not found." });
            } else {
                res.status(204).send();
            }
        }
    };

    model.deleteById(data, callback);
};