const shopModel = require('../models/shopModels');
const activityModel = require('../models/activityModels');
const inventoryModel = require('../models/inventoryModels');

module.exports.getItemDetailsAndValidateType = (itemType) => {
  return (req, res, next) => {
    const { item_id } = req.params;
    shopModel.getItemById({ item_id }, (error, results) => {
      if (error) {
        return res.status(500).json(error);
      }
      if (results.length === 0) {
        return res.status(400).json({ error: 'Item not found' });
      }
      if (results[0].item_type !== itemType) {
        return res.status(400).json({ error: `Invalid item type for this activity. Expected ${itemType}, but got ${results[0].item_type}` });
      }
      req.itemDetails = results[0];
      next();
    });
  };
};

module.exports.checkInventory = (req, res, next) => {
  const { user_id, item_id } = req.params;
  inventoryModel.checkItemInInventory({ user_id, item_id }, (error, results) => {
    if (error) {
      return res.status(500).json(error);
    }
    if (results.length === 0 || results[0].quantity <= 0) {
      return res.status(400).json({ error: 'Item not available in inventory' });
    }
    next();
  });
};

module.exports.updatePetStats = (statType) => {
  return (req, res, next) => {
    const { pet_id } = req.params;
    const effectValue = req.itemDetails.effect_value;
    let updateData = { pet_id };
    updateData[statType] = effectValue;

    activityModel.updatePetStats(updateData, (error) => {
      if (error) {
        return res.status(500).json(error);
      }
      next();
    });
  };
};

module.exports.removeItemFromInventory = (req, res, next) => {
  const { user_id, item_id } = req.params;
  inventoryModel.removeItemFromInventory({ user_id, item_id }, (error) => {
    if (error) {
      return res.status(500).json(error);
    }
    next();
  });
};

module.exports.logActivity = (activityType) => {
  return (req, res) => {
    const { pet_id, user_id, item_id } = req.params;
    const data = { pet_id, user_id, item_id, activity_type: activityType };
    activityModel.insertActivity(data, (error) => {
      if (error) {
        return res.status(500).json(error);
      }
      res.status(200).json({ message: `Pet ${activityType} successfully`, ...data });
    });
  };
};
