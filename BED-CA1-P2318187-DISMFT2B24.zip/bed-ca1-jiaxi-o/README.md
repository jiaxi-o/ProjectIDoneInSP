# Starter Repository for Assignment
You are required to build your folder structures for your project.

# Overview of application
This application is to implement a gamified platform that encourage users to complete the surveys

# Prerequisites
Software needed to run this application is Postman. To see the tables clearly, you can use MySQL Workbench.
Ensure that the following dependencies are installed:

- Node.js
- npm (Node Package Manager)

# Installation of dependencies 
To install dependencies, you can run "npm install" to install all dependencies I have used for this application. To check the dependencies, go to package.json and ensure that you have the following dependencies:
- dotenv
- express
- jest
- mysql2
- nodemon
- supertest

# Check scripts
Check that the scripts in package.json are as follows: 
"scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "init_tables": "node src/configs/initTables.js",
    "start": "node index.js",
    "dev": "nodemon ./src/index.js"
}

## Clone the Repository

1. Open Visual Studio Code (VSCode) on your local machine.

2. Click on the "Source Control" icon in the left sidebar (the icon looks like a branch).

3. Click on the "Clone Repository" button.

4. In the repository URL input field, enter `https://github.com/ST0503-BED/bed-ca1-jiaxi-o`.

5. Choose a local directory where you want to clone the repository.

6. Click on the "Clone" button to start the cloning process.

# Set Up Environment Variables
## Create a .env file in the root directory and configure the following variables:

DB_HOST=your_database_host
DB_USER=your_database_user
DB_PASSWORD=your_database_password
DB_NAME=your_database_name

# Initialize the Database
## Run the following command to create and initialize the database tables:
npm run init_tables

# Start the Server
## To start the server, you have two options:
1. npm start
2. npm run dev

## The server will start and listen on the specified port (default is 3000). The API endpoints can be accessed using tools like Postman or through a web browser:
http://localhost:3000

# API Endpoints
## Section A: Survey System Endpoints
1. User Endpoints (/users)
## POST /users: Create a new user.
- Description: This endpoint creates a new user with the provided username. If the username already exists, it returns a 409 Conflict error.
## GET /users: Retrieve all users.
- Description: This endpoint retrieves a list of all users in the database.
## GET /users/: Retrieve a user by ID.
- Description: This endpoint retrieves the details of a specific user by their ID, including their completed survey questions.
## PUT /users/id : Update a user by ID.
### Description: This endpoint updates the username of a specific user by their ID. If the username already exists or the user ID is not found, appropriate error messages are returned.
## DELETE /users/id : Delete a user by ID.
- Description: This endpoint deletes a specific user by their ID. If the user is not found, a 404 error is returned.
2. Question Endpoints (/questions)
## POST /questions: Create a new survey question.
- Description: This endpoint allows a user to create a new survey question. The user must provide their ID and the question text.
## GET /questions: Retrieve all survey questions.
- Description: This endpoint retrieves a list of all survey questions in the database.
## GET /questions/id : Retrieve a survey question by ID.
- Description: This endpoint retrieves the details of a specific survey question by its ID.
## PUT /questions/ : Update a survey question by ID.
- Description: This endpoint updates the text of a specific survey question by its ID. The user must be the creator of the question to update it.
## DELETE /questions/ : Delete a survey question by ID.
- Description: This endpoint deletes a specific survey question by its ID. If the question is not found, a 404 error is returned.
3. Answer Endpoints (/questions/:question_id/answers)
## POST /questions/{questio_id}/answers: Create a new answer for a specific survey question.
- Description: This endpoint allows a user to create a new answer for a specific survey question.
## GET /questions/{question_id}/answers: Retrieve all answers for a specific survey question.
### Description: This endpoint retrieves all answers for a specific survey question.
Section B: Fantasy Adventures and Pet Guardians Endpoints
1. Pet Endpoints (/pets)
- POST /
/createPet: Create a new pet for a specific user.
Description: This endpoint creates a new pet for a user specified by their user ID. The user must provide the pet's name, breed, and other attributes.
- GET /allPets: Retrieve all pets.
Description: This endpoint retrieves a list of all pets in the database.
- GET /user/
: Retrieve all pets for a specific user.
Description: This endpoint retrieves all pets owned by a specific user.
- GET /
: Retrieve a pet by ID.
Description: This endpoint retrieves the details of a specific pet by its ID.
- PUT /
/pets/
: Update a pet by ID for a specific user.
Description: This endpoint updates the details of a specific pet by its ID. The user ID must match the owner ID of the pet.
- DELETE /
/pets/
: Delete a pet by ID for a specific user.
Description: This endpoint deletes a specific pet by its ID. The user ID must match the owner ID of the pet.
2. Quest Endpoints (/quests)
- POST /quests: Create a new quest.
Description: This endpoint creates a new quest with the provided name, description, and reward points.
- GET /quests: Retrieve all quests.
Description: This endpoint retrieves a list of all quests in the database.
- GET /quests/
: Retrieve a quest by ID.
Description: This endpoint retrieves the details of a specific quest by its ID.
- PUT /quests/
: Update a quest by ID.
Description: This endpoint updates the details of a specific quest by its ID.
- DELETE /quests/
: Delete a quest by ID.
Description: This endpoint deletes a specific quest by its ID.
- POST /quests/
/accept/user/
: Accept a quest for a specific user.
Description: This endpoint allows a user to accept a quest by specifying the quest ID and user ID.
- POST /quests/
/complete/user/
: Complete a quest for a specific user.
Description: This endpoint allows a user to complete a quest by specifying the quest ID and user ID.
3. Shop Endpoints (/shop)
- POST /shop/items: Create a new shop item.
Description: This endpoint creates a new item for the shop with the provided name, description, price, item type, and effect value.
- GET /shop/items: Retrieve all shop items.
Description: This endpoint retrieves a list of all items available in the shop.
- POST /user/
/purchase/items/
: Purchase a shop item for a specific user.
Description: This endpoint allows a user to purchase an item from the shop by specifying the user ID and item ID.
4. Activity Endpoints (/activities)
- POST /
/
/feed/
: Feed a pet with a specific item.
Description: This endpoint allows a user to feed their pet with a specific item, affecting the pet's hunger level.
- POST /
/
/groom/
: Groom a pet with a specific item.
Description: This endpoint allows a user to groom their pet with a specific item, affecting the pet's happiness level.
- POST /
/
/train/
: Train a pet with a specific item.
Description: This endpoint allows a user to train their pet with a specific item, affecting the pet's health level.
5. Inventory Endpoints (/inventory)
- GET /user/
: Retrieve all inventory items for a specific user.
Description: This endpoint retrieves all inventory items owned by a specific user.

# Project Structure
## Controllers: Business logic for handling requests and responses.
## Routes: Define the API endpoints and link them to the controllers.
## Models: Database interaction and schema definitions.

# Middleware Functions in Activity Routes
## The activity routes use middleware-like functions to validate and process the activities. These functions include:

- getItemDetailsAndValidateType
Description: This function validates the type of the item being used for the activity. It checks if the item exists and matches the expected item type (e.g., snack, grooming, training).
- checkInventory
Description: This function checks if the user has the specified item in their inventory and ensures the item quantity is sufficient.
- updatePetStats
Description: This function updates the pet's stats (hunger, happiness, health) based on the effect value of the item used.
- removeItemFromInventory
Description: This function removes the used item from the user's inventory after the activity is performed.
- logActivity
Description: This function logs the activity performed by the user and pet, recording details such as the activity type and timestamps.
# Error Handling
The application includes robust error handling to manage various error scenarios:

-User Endpoints
Description: Handles errors such as missing required fields, user not found, and username conflicts. Returns appropriate status codes and error messages.
-Question Endpoints
Description: Handles errors such as missing required fields, question not found, and permission issues for updating questions. Returns appropriate status codes and error messages.
-Answer Endpoints
Description: Handles errors such as missing required fields, question or user not found, and database insertion errors. Returns appropriate status codes and error messages.
-Pet Endpoints
Description: Handles errors such as missing required fields, pet not found, and permission issues for updating or deleting pets. Returns appropriate status codes and error messages.
-Quest Endpoints
Description: Handles errors such as missing required fields, quest not found, and permission issues for accepting or completing quests. Returns appropriate status codes and error messages.
-Shop Endpoints
Description: Handles errors such as missing required fields, item not found, and insufficient points for purchasing items. Returns appropriate status codes and error messages.
-Activity Endpoints
Description: Handles errors such as item not found, invalid item type, insufficient inventory, and database update errors. Returns appropriate status codes and error messages.